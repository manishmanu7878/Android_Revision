package com.manish.assessmentexpense


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.RecyclerView

data class RecDsh(
    val itemName : String,
    val cost : Int,
    val icon : Int
)

class RecDshAdapter(
    private val context : Context,
    private val dataSource : List<RecDsh>
) : RecyclerView.Adapter<RecDshViewHolder>() {


    private val _itemClick = MutableLiveData<RecDsh>()
    val itemClick : LiveData<RecDsh> = _itemClick

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecDshViewHolder {
        val vw = LayoutInflater.from(context).inflate(R.layout.rec_item, parent, false)
        return RecDshViewHolder(vw)
    }


    override fun onBindViewHolder(holder: RecDshViewHolder, position: Int) {

        holder.itemView.setOnClickListener {
            val clickedItem = it.tag as RecDsh
//            itemClick.onNext(clickedItem)
            _itemClick.value = clickedItem
        }

        holder.itemView.tag = dataSource[position]
        holder.icon().setImageResource(dataSource[position].icon)
        holder.label().setText(dataSource[position].itemName)
        holder.label().setText(dataSource[position].cost)
    }

    override fun getItemCount(): Int = dataSource.size
}

class RecDshViewHolder(
    private val view: View
) : RecyclerView.ViewHolder(view) {

    fun icon() = view.findViewById<ImageView>(R.id.icon)

    fun label() = view.findViewById<TextView>(R.id.txtVwOne)

    fun label() = view.findViewById<TextView>(R.id.txtVwTwo)
}