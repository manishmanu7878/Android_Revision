package com.manish.assessmentexpense

import androidx.lifecycle.ViewModel

open class SharedViewModel : ViewModel() {}