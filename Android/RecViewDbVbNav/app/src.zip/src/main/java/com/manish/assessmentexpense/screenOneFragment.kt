package com.manish.assessmentexpense

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.commit
import androidx.fragment.app.replace
import androidx.recyclerview.widget.GridLayoutManager
import com.manish.assessmentexpense.databinding.FragmentScreenOneBinding

class screenOneFragment : Fragment() {
    private val viewModel: SharedViewModel by activityViewModels()

    private lateinit var binding: FragmentScreenOneBinding
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = DataBindingUtil.inflate<FragmentScreenOneBinding>(
            inflater,
            R.layout.fragment_screen_one,
            container,
            false
        )
        binding.lifecycleOwner = this
        binding.vm = viewModel


        return binding.root
    }
}
